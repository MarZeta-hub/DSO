//
// Created by jrivaden on 5/2/20.
//

#ifndef MY_IO_H
#define MY_IO_H
#include <time.h>
#include "mythread.h"

int ticks_to_seconds(int ticks);


int seconds_to_ticks (int seconds);

#endif //P1_PLANIFICADOR_2020_MY_IO_H
